package com.example.tugassqldatabase;

public class CourseModal {

    private String courseNama;
    private String courseNik;
    private String courseAlamat;
    private String coursePekerjaan;
    private int id;

    public String getCourseNama() { return courseNama; }

    public void setCourseNama(String courseNama)
    {
        this.courseNama = courseNama;
    }

    public String getCourseNik()
    {
        return courseNik;
    }

    public void setCourseDuration(String courseNik)
    {
        this.courseNik = courseNik;
    }

    public String getCourseAlamat() { return courseAlamat; }

    public void setCourseAlamat(String courseAlamat)
    {
        this.courseAlamat = courseAlamat;
    }

    public String getCoursePekerjaan()
    {
        return coursePekerjaan;
    }

    public void
    setCoursePekerjaan(String coursePekerjaan)
    {
        this.coursePekerjaan = coursePekerjaan;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }


    public CourseModal(String courseNama,
                       String courseNik,
                       String courseAlamat,
                       String coursePekerjaan)
    {
        this.courseNama = courseNama;
        this.courseNik = courseNik;
        this.courseAlamat = courseAlamat;
        this.coursePekerjaan = coursePekerjaan;
    }

}
