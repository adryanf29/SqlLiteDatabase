package com.example.tugassqldatabase;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CourseRVAdapter extends RecyclerView.Adapter<CourseRVAdapter.ViewHolder> {

    private ArrayList<CourseModal> courseModalArrayList;
    private Context context;

    public CourseRVAdapter(ArrayList<CourseModal> courseModalArrayList, Context context) {
        this.courseModalArrayList = courseModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        CourseModal modal = courseModalArrayList.get(position);
        holder.courseNamaTV.setText(modal.getCourseNama());
        holder.courseNikTV.setText(modal.getCourseNik());
        holder.courseAlamatTV.setText(modal.getCourseAlamat());
        holder.coursePekerjaanTV.setText(modal.getCoursePekerjaan());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdateCourseActivity.class);

                // below we are passing all our values.
                i.putExtra("nama", modal.getCourseNama());
                i.putExtra("nik", modal.getCourseNik());
                i.putExtra("alamat", modal.getCourseAlamat());
                i.putExtra("pekerjaan", modal.getCoursePekerjaan());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {

        return courseModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        private TextView courseNamaTV, courseNikTV, courseAlamatTV, coursePekerjaanTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            courseNamaTV = itemView.findViewById(R.id.idTVCourseNama);
            courseNikTV = itemView.findViewById(R.id.idTVCourseNik);
            courseAlamatTV = itemView.findViewById(R.id.idTVCourseAlamat);
            coursePekerjaanTV = itemView.findViewById(R.id.idTVCoursePekerjaan);
        }
    }
}
