package com.example.tugassqldatabase;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateCourseActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText courseNamaEdt, courseNikEdt, courseAlamatEdt, coursePekerjaanEdt;
    private Button updateDataBtn,   deleteCourseBtn;
    private DBHandler dbHandler;
    String courseNama, courseNik, courseAlamat, coursePekerjaan;

    ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_course);

        courseNamaEdt = findViewById(R.id.idEdtCourseNama);
        courseNikEdt = findViewById(R.id.idEdtCourseNik);
        courseAlamatEdt = findViewById(R.id.idEdtCourseAlamat);
        coursePekerjaanEdt = findViewById(R.id.idEdtCoursePekerjaan);
        updateDataBtn = findViewById(R.id.idBtnUpdateData);
        deleteCourseBtn = findViewById(R.id.idBtnDelete);

        deleteCourseBtn.setOnClickListener(this);

        actionBar = getSupportActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        dbHandler = new DBHandler(UpdateCourseActivity.this);

        courseNama = getIntent().getStringExtra("nama");
        courseNik = getIntent().getStringExtra("nik");
        courseAlamat = getIntent().getStringExtra("alamat");
        coursePekerjaan = getIntent().getStringExtra("pekerjaan");

        courseNamaEdt.setText(courseNama);
        courseNikEdt.setText(courseNik);
        courseAlamatEdt.setText(courseAlamat);
        coursePekerjaanEdt.setText(coursePekerjaan);


        updateDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dbHandler.updateCourse(courseNama, courseNamaEdt.getText().toString(), courseNikEdt.getText().toString(), courseAlamatEdt.getText().toString(), coursePekerjaanEdt.getText().toString());

                Toast.makeText(UpdateCourseActivity.this, "Data Berhasil Di Ubah", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdateCourseActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onClick(View view) {
        if (view == deleteCourseBtn) {
            tampilpesandialog();
        }

    }

    private void tampilpesandialog() {
        AlertDialog.Builder pesan = new AlertDialog.Builder(this);
        pesan.setTitle("Peringatan")
                .setMessage("Apakah Anda Yakin Ingin Menghapus Data ini ?")
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                })
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dbHandler.deleteCourse(courseNama);
                        Toast.makeText(UpdateCourseActivity.this, "Data Berhasil Di hapus", Toast.LENGTH_SHORT).show();
                        Intent in = new Intent(UpdateCourseActivity.this, MainActivity.class);
                        startActivity(in);
                    }
                });
        AlertDialog alertDialog = pesan.create();

        alertDialog.show();

    }

}