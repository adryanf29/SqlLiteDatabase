package com.example.tugassqldatabase;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText namaEdt, nikEdt, alamatEdt, pekerjaanEdt ;

    private Button addTambahBtn,btnLihatData;
    private DBHandler dbHandler;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        namaEdt = findViewById(R.id.idEdtCourseNama);
        nikEdt = findViewById(R.id.idEdtCourseNik);
        alamatEdt = findViewById(R.id.idEdtCourseAlamat);
        pekerjaanEdt = findViewById(R.id.idEdtCoursePekerjaan);
        addTambahBtn = findViewById(R.id.idBtnAddTambah);
        btnLihatData = findViewById(R.id.idBtnLhtDt);

        dbHandler = new DBHandler(MainActivity.this);


        addTambahBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String courseNama = namaEdt.getText().toString();
                String courseNik = nikEdt.getText().toString();
                String courseAlamat = alamatEdt.getText().toString();
                String coursePekerjaan = pekerjaanEdt.getText().toString();

                if (courseNama.isEmpty() || courseNik.isEmpty() || courseAlamat.isEmpty() || coursePekerjaan.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Silahkan Masukan Data Terlebih dahulu", Toast.LENGTH_SHORT).show();
                    return;

                }

                dbHandler.addNewCourse(courseNama, courseNik, courseAlamat, coursePekerjaan);

                Toast.makeText(MainActivity.this, "Data Berhasil Di Tambahkan", Toast.LENGTH_SHORT).show();
                namaEdt.setText("");
                nikEdt.setText("");
                alamatEdt.setText("");
                pekerjaanEdt.setText("");

            }
        });
        btnLihatData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ViewCourses.class);
                startActivity(i);
            }
        });


    }

}