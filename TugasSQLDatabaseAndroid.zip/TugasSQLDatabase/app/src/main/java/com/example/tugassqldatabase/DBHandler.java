package com.example.tugassqldatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Button;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "datadb";


    private static final int DB_VERSION = 1;

    private static final String TABLE_NAME = "mydata";

    private static final String ID_COL = "id";

    // below variable is for our course name column
    private static final String NAMA_COL = "nama";

    // below variable id for our course duration column.
    private static final String NIK_COL = "nik";

    // below variable for our course description column.
    private static final String ALAMAT_COL= "alamat";

    // below variable is for our course tracks column.
    private static final String PEKERJAAN_COL = "pekerjaan";


    Button btnhps;

    // creating a constructor for our database handler.
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAMA_COL + " TEXT,"
                + NIK_COL + " TEXT,"
                + ALAMAT_COL + " TEXT,"
                + PEKERJAAN_COL + " TEXT)";

        db.execSQL(query);

    }

    public void addNewCourse(String nama, String nik, String alamat, String pekerjaan) {


        SQLiteDatabase db = this.getWritableDatabase();


        ContentValues values = new ContentValues();

        values.put(NAMA_COL, nama);
        values.put(NIK_COL, nik);
        values.put(ALAMAT_COL, alamat);
        values.put(PEKERJAAN_COL, pekerjaan);


        db.insert(TABLE_NAME, null, values);


        db.close();
    }

    public ArrayList<CourseModal> readCourses() {

        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        // on below line we are creating a new array list.
        ArrayList<CourseModal> courseModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCourses.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                courseModalArrayList.add(new CourseModal(cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3),
                        cursorCourses.getString(4)));
            } while (cursorCourses.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCourses.close();
        return courseModalArrayList;
    }

    public void updateCourse(String originalCourseNama, String courseNama, String courseNik,
                             String courseAlamat, String coursePekerjaan) {


        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();


        values.put(NAMA_COL, courseNama);
        values.put(NIK_COL, courseNik);
        values.put(ALAMAT_COL, courseAlamat);
        values.put(PEKERJAAN_COL, coursePekerjaan);

        db.update(TABLE_NAME, values, "nama=?", new String[]{originalCourseNama});
        db.close();
    }


    public void deleteCourse(String courseName) {


        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, "nama=?", new String[]{courseName});
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }
}
